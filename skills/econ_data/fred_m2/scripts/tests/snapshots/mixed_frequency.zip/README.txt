----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-08-31 6:27 am CDT
----------------------------------------------------------------

-----  --------------------------------------------------------  ------------------------
M2SL   M2, Billions of Dollars, Monthly, Seasonally Adjusted     Data Updated: 2026-08-25
WM2NS  M2, Billions of Dollars, Weekly, Not Seasonally Adjusted  Data Updated: 2026-08-25
-----  --------------------------------------------------------  ------------------------

